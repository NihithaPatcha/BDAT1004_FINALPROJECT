from flask import Flask, render_template


app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True


# client = MongoClient("mongodb+srv://Bhavya1:bhavya@cluster0.ywseg.mongodb.net/mydatabase?ss1 = true&ss1_cert_reqs=CERT_NONE")
# db = client.get_database('mydatabase')

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/home')
def home():
    return render_template("home.html")

@app.route("/chart")
def chart():


    return render_template("Barchart.html")


if __name__ == "__main__":
    app.run(debug=True)